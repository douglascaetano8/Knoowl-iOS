//
//  Geolocalizacao+CoreDataProperties.m
//  ClassHive
//
//  Created by Giga Digital on 23/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import "Geolocalizacao+CoreDataProperties.h"

@implementation Geolocalizacao (CoreDataProperties)

+ (NSFetchRequest<Geolocalizacao *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"Geolocalizacao"];
}

@dynamic latitude;
@dynamic longitude;
@dynamic endereco;

@end
