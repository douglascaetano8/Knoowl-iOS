//
//  Endereco+CoreDataProperties.h
//  ClassHive
//
//  Created by Giga Digital on 23/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import "Endereco+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Endereco (CoreDataProperties)

+ (NSFetchRequest<Endereco *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *bairro;
@property (nullable, nonatomic, copy) NSString *cep;
@property (nullable, nonatomic, copy) NSString *cidade;
@property (nullable, nonatomic, copy) NSString *numero;
@property (nullable, nonatomic, retain) Geolocalizacao *geolocalizacao;
@property (nullable, nonatomic, retain) Contato *contato;

@end

NS_ASSUME_NONNULL_END
