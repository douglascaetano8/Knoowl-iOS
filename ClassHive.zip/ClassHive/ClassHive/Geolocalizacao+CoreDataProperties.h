//
//  Geolocalizacao+CoreDataProperties.h
//  ClassHive
//
//  Created by Giga Digital on 23/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import "Geolocalizacao+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Geolocalizacao (CoreDataProperties)

+ (NSFetchRequest<Geolocalizacao *> *)fetchRequest;

@property (nonatomic) double latitude;
@property (nonatomic) double longitude;
@property (nullable, nonatomic, retain) Endereco *endereco;

@end

NS_ASSUME_NONNULL_END
