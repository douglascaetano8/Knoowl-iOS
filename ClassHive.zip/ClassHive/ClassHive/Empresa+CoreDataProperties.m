//
//  Empresa+CoreDataProperties.m
//  ClassHive
//
//  Created by Giga Digital on 23/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import "Empresa+CoreDataProperties.h"

@implementation Empresa (CoreDataProperties)

+ (NSFetchRequest<Empresa *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"Empresa"];
}

@dynamic nomeFantasia;
@dynamic razaoSocial;
@dynamic slogan;
@dynamic contato;

@end
