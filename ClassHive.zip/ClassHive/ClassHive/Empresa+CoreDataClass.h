//
//  Empresa+CoreDataClass.h
//  ClassHive
//
//  Created by Giga Digital on 23/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Contato;

NS_ASSUME_NONNULL_BEGIN

@interface Empresa : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Empresa+CoreDataProperties.h"
