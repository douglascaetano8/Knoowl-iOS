//
//  Contato+CoreDataProperties.m
//  ClassHive
//
//  Created by Giga Digital on 23/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import "Contato+CoreDataProperties.h"

@implementation Contato (CoreDataProperties)

+ (NSFetchRequest<Contato *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"Contato"];
}

@dynamic email;
@dynamic foto;
@dynamic nome;
@dynamic site;
@dynamic telefone;
@dynamic usuario;
@dynamic empresa;
@dynamic endereco;

@end
