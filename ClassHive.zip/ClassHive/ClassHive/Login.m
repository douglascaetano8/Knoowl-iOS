//
//  Login.m
//  ClassHive
//
//  Created by Giga Digital on 12/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import "Login.h"
#import "Contato+CoreDataClass.h"
#import "Empresa+CoreDataClass.h"
#import "Endereco+CoreDataClass.h"
#import "Geolocalizacao+CoreDataClass.h"
#import "AppDelegate.h"

@interface Login () <NSURLSessionDataDelegate, UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UIImageView *ImageViewLogo;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldUsuario;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldSenha;
@property (weak, nonatomic) IBOutlet UIButton *ButtonEntrar;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constraintLogoCentro;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constraintUsuarioDireita;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constraintSenhaDireita;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constraintButtonEntrar;

@property (strong, nonatomic) NSMutableData *bytesRespostaContatos;

@end

@implementation Login
static NSString * const kChaveBancoCarregado = @"bancoCarregado";

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //MANUSEIO DAS CONSTRAINTS PARA A ANIMAÇÃO
    [self.constraintLogoCentro setConstant:(self.view.frame.size.width + 100) * (-1)];
    [self.constraintUsuarioDireita setConstant:self.view.frame.size.width + 100];
    [self.constraintSenhaDireita setConstant:self.view.frame.size.width + 100];
    
    [self.ButtonEntrar setAlpha:0];
    
    //SETANDO O DELEGATE DOS TEXTFIELDS
    [self.TextFieldUsuario setDelegate:self];
    [self.TextFieldSenha setDelegate:self];
}

- (void)viewDidAppear:(BOOL)animated {
    //EVENTOS DE OBSERVAÇÃO DO TECLADO
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(tecladoApareceu:)
                                                 name:UIKeyboardDidShowNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(tecladoSumiu:)
                                                 name:UIKeyboardDidHideNotification
                                               object:nil];
    
    //ANIMAÇÃO
    [UIView animateWithDuration:0.5
                          delay:0
                        options:UIViewAnimationOptionCurveLinear
                     animations:^{
                         self.constraintLogoCentro.constant = 0;
                         [self.view layoutIfNeeded];
                     }
                     completion:^(BOOL finished){
                         if(finished) {
                             [UIView animateWithDuration:0.5
                                                   delay:0
                                                 options:UIViewAnimationOptionCurveLinear
                                              animations:^{
                                                  [self.constraintUsuarioDireita setConstant:32];
                                                  [self.view layoutIfNeeded];
                                              }
                                              completion:^(BOOL finished){
                                                  if(finished) {
                                                      [UIView animateWithDuration:0.5
                                                                            delay:0
                                                                          options:UIViewAnimationOptionCurveLinear
                                                                       animations:^{
                                                                           [self.constraintSenhaDireita setConstant:32];
                                                                           [self.view layoutIfNeeded];
                                                                       }
                                                                       completion:^(BOOL finished){
                                                                           if(finished) {
                                                                               [UIView animateWithDuration:0.5
                                                                                                     delay:0
                                                                                                   options:UIViewAnimationOptionCurveLinear
                                                                                                animations:^{
                                                                                                    [self.ButtonEntrar setAlpha:1];
                                                                                                }
                                                                                                completion:^(BOOL finished){
                                                                                                    
                                                                                                }];
                                                                           }
                                                                       }];
                                                  }
                                              }];
                         }
                     }];
    
    //DOWNLOAD DOS DADOS DOS CONTATOS
    BOOL bancoCarregado = [[NSUserDefaults standardUserDefaults] boolForKey:kChaveBancoCarregado];
    if(!bancoCarregado) {
        self.bytesRespostaContatos = [NSMutableData new];
        
        NSURLSessionConfiguration *sc = [NSURLSessionConfiguration defaultSessionConfiguration];
        NSURLSession *session = [NSURLSession sessionWithConfiguration:sc
                                                              delegate:self
                                                         delegateQueue:nil];
    
        NSURLSessionDataTask *taskContatos = [session dataTaskWithURL:[NSURL URLWithString:@"http://jsonplaceholder.typicode.com/users"]];
        [taskContatos resume];
        
        //EXIBIR O NETWORK ACTIVITY INDICATION
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    }
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIKeyboardDidShowNotification
                                                  object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIKeyboardDidHideNotification
                                                  object:nil];
}

- (void) tecladoApareceu: (NSNotification *) sender {
    NSDictionary* dicionarioDeInformacoesSobreTeclado = [sender userInfo];
    CGRect frameDoTeclado = [[dicionarioDeInformacoesSobreTeclado valueForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    
    [self.constraintButtonEntrar setConstant: (frameDoTeclado.size.height + 32)];
    
}

- (void) tecladoSumiu: (NSNotification *) sender {
    [self.constraintButtonEntrar setConstant:0];
}

- (IBAction)ButtonEntrar_Tapped:(UIButton *)sender {
    [self validarLogin];
}

- (void)validarLogin {
    if([self.TextFieldUsuario.text isEqualToString:@"teste"] && [self.TextFieldSenha.text isEqualToString:@"teste"]) {
        [self performSegueWithIdentifier:@"SegueLogar" sender:self];
    }
    else {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Erro de Autenticação"
                                                                                 message:@"Usuário e/ou senha incorretos"
                                                                          preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
    }
}


#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    if (textField == self.TextFieldUsuario) {
        [self.TextFieldSenha becomeFirstResponder];
    }
    if (textField == self.TextFieldSenha) {
        [self validarLogin];
    }
    return YES;
}


#pragma mark - NSURLSessionDelegate
- (void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)dataTask didReceiveData:(NSData *)data {
    [self.bytesRespostaContatos appendData:data];
}

- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didCompleteWithError:(nullable NSError *)error {
    if(error) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Falha ao Obter Dados"
                                                                                 message:@"Ocorreu um erro ao obter os dados dos contatos"
                                                                          preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
    }
    else {
        NSError *erroJSON;
        
        NSArray<NSDictionary *> *contatosRecebidos = [NSJSONSerialization JSONObjectWithData:self.bytesRespostaContatos
                                                                                     options:kNilOptions
                                                                                       error:&erroJSON];
        
        if(erroJSON) {
            //NSLog(@"\n\n\nArquivo JSON inválido! %@\n\n\n", erroJSON);
            
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Falha ao Ler os Dados"
                                                                                     message:@"O arquivo de contatos recebido é inválido"
                                                                              preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            
            [self presentViewController:alertController animated:YES completion:nil];
        }
        else {
            AppDelegate *delegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
            NSPersistentContainer *containerPersistencia = delegate.persistentContainer;
            NSManagedObjectContext *context = containerPersistencia.viewContext;
            
            //PERCORRE OS CONTATOS RECEBIDOS SALVANDO NO BANCO DE DADOS
            for(NSDictionary *contato in contatosRecebidos) {
                //DOWNLOAD DA FOTO
                NSURLSessionDownloadTask *taskFoto = [session downloadTaskWithURL:[NSURL URLWithString:@"http://www.lorempixel.com/128/128/people"] completionHandler:^(NSURL *location, NSURLResponse *response, NSError *error){
                    if(error) {
                        //NSLog(@"Falha ao baixar a foto: %@", error);
                        
                        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Erro"
                                                                                                 message:@"Ocorreu um erro ao baixar a foto do contato."
                                                                                          preferredStyle:UIAlertControllerStyleAlert];
                        
                        [alertController addAction:[UIAlertAction actionWithTitle:@"OK"
                                                                            style:UIAlertActionStyleCancel
                                                                          handler:nil]];
                    }
                    else {
                        Contato *novoContato = [NSEntityDescription insertNewObjectForEntityForName:@"Contato" inManagedObjectContext:context];
                        
                        //DADOS GERAIS DO CONTATO
                        [novoContato setFoto:[NSData dataWithContentsOfURL:location]];
                        [novoContato setNome:[contato objectForKey:@"name"]];
                        [novoContato setUsuario:[contato objectForKey:@"username"]];
                        [novoContato setTelefone:[contato objectForKey:@"phone"]];
                        [novoContato setEmail:[contato objectForKey:@"email"]];
                        [novoContato setSite:[contato objectForKey:@"website"]];
                        
                        //DADOS DO ENDEREÇO
                        Endereco *novoEndereco = [NSEntityDescription insertNewObjectForEntityForName:@"Endereco" inManagedObjectContext:context];
                        
                        NSDictionary *endereco = contato[@"address"];
                        [novoEndereco setCep:[endereco objectForKey:@"zipcode"]];
                        [novoEndereco setCidade:[endereco objectForKey:@"city"]];
                        [novoEndereco setBairro:[endereco objectForKey:@"street"]];
                        [novoEndereco setNumero:[endereco objectForKey:@"suite"]];
                        
                        //GEOLOCALIZAÇÃO
                        Geolocalizacao *novaGeolocalizacao = [NSEntityDescription insertNewObjectForEntityForName:@"Geolocalizacao" inManagedObjectContext:context];
                        
                        NSDictionary *geolocalizacao = endereco[@"geo"];
                        [novaGeolocalizacao setLatitude:[[geolocalizacao objectForKey:@"lat"] doubleValue]];
                        [novaGeolocalizacao setLongitude:[[geolocalizacao objectForKey:@"lng"] doubleValue]];
                        
                        [novoEndereco setGeolocalizacao:novaGeolocalizacao];
                        [novoContato setEndereco:novoEndereco];
                        
                        //DADOS DA EMPRESA
                        Empresa *novaEmpresa = [NSEntityDescription insertNewObjectForEntityForName:@"Empresa" inManagedObjectContext:context];
                        
                        NSDictionary *empresa = contato[@"company"];
                        [novaEmpresa setRazaoSocial:[empresa objectForKey:@"bs"]];
                        [novaEmpresa setNomeFantasia:[empresa objectForKey:@"name"]];
                        [novaEmpresa setSlogan:[empresa objectForKey:@"catchPhrase"]];
                        
                        [novoContato setEmpresa:novaEmpresa];
                    }
                }];
                
                [taskFoto resume];
            }
            
            //OCULTAR O NETWORK ACTIVITY INDICATION
            [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
            
            NSError *erroCoreData;
            if (![context save:&erroCoreData]) {
                //NSLog(@"\n\n\nErro ao salvar o contato! %@\n\n\n", erroCoreData);
                
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Erro"
                                                                                         message:@"Ocorreu um erro ao salvar os contatos recebidos."
                                                                                  preferredStyle:UIAlertControllerStyleAlert];
                
                [alertController addAction:[UIAlertAction actionWithTitle:@"OK"
                                                                    style:UIAlertActionStyleCancel
                                                                  handler:nil]];
            }
            else{
                [[NSUserDefaults standardUserDefaults] setBool:YES forKey:kChaveBancoCarregado];
            }
        }
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
