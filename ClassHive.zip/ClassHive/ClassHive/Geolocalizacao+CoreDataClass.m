//
//  Geolocalizacao+CoreDataClass.m
//  ClassHive
//
//  Created by Giga Digital on 23/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import "Geolocalizacao+CoreDataClass.h"
#import "Endereco+CoreDataClass.h"
@implementation Geolocalizacao

@end
