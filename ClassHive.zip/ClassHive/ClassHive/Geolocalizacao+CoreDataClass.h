//
//  Geolocalizacao+CoreDataClass.h
//  ClassHive
//
//  Created by Giga Digital on 23/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Endereco;

NS_ASSUME_NONNULL_BEGIN

@interface Geolocalizacao : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Geolocalizacao+CoreDataProperties.h"
