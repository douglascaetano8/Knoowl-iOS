//
//  FormContato.m
//  ClassHive
//
//  Created by Giga Digital on 12/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import "FormContato.h"
#import "Endereco+CoreDataClass.h"
#import "Geolocalizacao+CoreDataClass.h"
#import "Empresa+CoreDataClass.h"
#import "AppDelegate.h"
@import MobileCoreServices;
@import Photos;

@interface FormContato () <UIImagePickerControllerDelegate, UINavigationControllerDelegate>

@property (weak, nonatomic) IBOutlet UIImageView *ImageViewFoto;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldNome;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldTelefone;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldEmail;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldUsuario;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldSite;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldCep;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldCidade;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldBairro;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldNumero;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldLatitude;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldLongitude;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldRazaoSocial;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldNomeFantasia;
@property (weak, nonatomic) IBOutlet UITextField *TextFieldSlogan;

@end

@implementation FormContato

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //ARREDONDAMENTO DA IMAGEM
    self.ImageViewFoto.layer.cornerRadius = 5;
    self.ImageViewFoto.clipsToBounds = YES;
    
    //DEFINIÇÃO DO GESTO TAP DA IMAGEM
    UITapGestureRecognizer *onTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ImageViewFoto_Tapped)];
    onTap.numberOfTapsRequired = 1;
    [self.ImageViewFoto setUserInteractionEnabled:YES];
    [self.ImageViewFoto addGestureRecognizer:onTap];
    
    //BOTÃO DE SALVAR
    UIBarButtonItem *botaoSalvar = [[UIBarButtonItem alloc] initWithTitle:@"Salvar"
                                                                    style:UIBarButtonItemStylePlain
                                                                   target:self
                                                                   action:@selector(salvarContato:)];
    self.navigationItem.rightBarButtonItem = botaoSalvar;
    
    //INICIALIZAÇÃO DOS TEXTFIELDS, CASO SEJA EDIÇÃO
    if (self.contato) {
        [self.ImageViewFoto setImage:[UIImage imageWithData:[self.contato valueForKey:@"foto"]]];
        [self.TextFieldNome setText:[self.contato valueForKey:@"nome"]];
        [self.TextFieldTelefone setText:[self.contato valueForKey:@"telefone"]];
        [self.TextFieldEmail setText:[self.contato valueForKey:@"email"]];
        [self.TextFieldUsuario setText:[self.contato valueForKey:@"usuario"]];
        [self.TextFieldSite setText:[self.contato valueForKey:@"site"]];
        
        Endereco *endereco = [self.contato valueForKey:@"endereco"];
        [self.TextFieldCep setText:[endereco valueForKey:@"cep"]];
        [self.TextFieldCidade setText:[endereco valueForKey:@"cidade"]];
        [self.TextFieldBairro setText:[endereco valueForKey:@"bairro"]];
        [self.TextFieldNumero setText:[endereco valueForKey:@"numero"]];
        
        Geolocalizacao *geolocalizacao = [endereco valueForKey:@"geolocalizacao"];
        [self.TextFieldLatitude setText:[[geolocalizacao valueForKey:@"latitude"] stringValue]];
        [self.TextFieldLongitude setText:[[geolocalizacao valueForKey:@"longitude"] stringValue]];
        
        Empresa *empresa = [self.contato valueForKey:@"empresa"];
        [self.TextFieldRazaoSocial setText:[empresa valueForKey:@"razaoSocial"]];
        [self.TextFieldNomeFantasia setText:[empresa valueForKey:@"nomeFantasia"]];
        [self.TextFieldSlogan setText:[empresa valueForKey:@"slogan"]];
    }
}

- (void)ImageViewFoto_Tapped {
    __weak typeof(self) weakSelf = self;
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Envio de Foto"
                                                                             message:@"Selecione a forma de envio da foto"
                                                                      preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction *escolherFoto = [UIAlertAction actionWithTitle:@"Escolher Foto"
                                                           style:UIAlertActionStyleDefault
                                                         handler:^(UIAlertAction * acao) {
                                                             UIImagePickerController *picker = [UIImagePickerController new];
                                                             [picker setDelegate:weakSelf];
                                                             [picker setAllowsEditing:YES];
                                                             [picker setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
                                                             
                                                             [picker setMediaTypes:[UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypePhotoLibrary]];
                                                             
                                                             [weakSelf presentViewController:picker animated:YES completion:nil];
                                                         }];
    
    UIAlertAction *tirarFoto = [UIAlertAction actionWithTitle:@"Tirar Foto"
                                                        style:UIAlertActionStyleDefault
                                                      handler:^(UIAlertAction * acao) {
                                                          if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
                                                              UIImagePickerController *picker = [UIImagePickerController new];
                                                              [picker setDelegate:weakSelf];
                                                              [picker setAllowsEditing:YES];
                                                              [picker setSourceType:UIImagePickerControllerSourceTypeCamera];
                                                              [picker setShowsCameraControls:YES];
                                                              [picker setMediaTypes:@[((NSString *) kUTTypeImage)]];
                                                              
                                                              [weakSelf presentViewController:picker animated:YES completion:nil];
                                                              
                                                          }
                                                          else {
                                                              UIAlertController *alertController2 = [UIAlertController alertControllerWithTitle:@"Use um iPhone"
                                                                                                                                        message:@"É necessário um dispositivo físico que possua câmera."
                                                                                                                                 preferredStyle:UIAlertControllerStyleAlert];
                                                              
                                                              [alertController2 addAction:[UIAlertAction actionWithTitle:@"OK"
                                                                                                                   style:UIAlertActionStyleCancel
                                                                                                   handler:nil]];
                                                              
                                                              [weakSelf presentViewController:alertController2 animated:YES completion:nil];
                                                          }
                                                      }];
    
    UIAlertAction *cancelar = [UIAlertAction actionWithTitle:@"Cancelar" style:UIAlertActionStyleCancel handler:nil];
    
    [alertController addAction:escolherFoto];
    [alertController addAction:tirarFoto];
    [alertController addAction:cancelar];
    
    [self presentViewController:alertController animated:YES completion:nil];
}

- (IBAction)salvarContato:(UIButton *) sender {
    AppDelegate *delegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    NSPersistentContainer *containerPersistencia = delegate.persistentContainer;
    NSManagedObjectContext *context = containerPersistencia.viewContext;
    
    if (self.contato) {
        //DADOS GERAIS DO CONTATO
        [self.contato setFoto:UIImagePNGRepresentation(self.ImageViewFoto.image)];
        [self.contato setNome:self.TextFieldNome.text];
        [self.contato setTelefone:self.TextFieldTelefone.text];
        [self.contato setEmail:self.TextFieldEmail.text];
        [self.contato setUsuario:self.TextFieldUsuario.text];
        [self.contato setSite:self.TextFieldSite.text];
        
        //DADOS DO ENDEREÇO
        [self.contato.endereco setCep:self.TextFieldCep.text];
        [self.contato.endereco setCidade:self.TextFieldCidade.text];
        [self.contato.endereco setBairro:self.TextFieldBairro.text];
        [self.contato.endereco setNumero:self.TextFieldNumero.text];
        
        //GEOLOCALIZAÇÃO
        [self.contato.endereco.geolocalizacao setLatitude:[self.TextFieldLatitude.text doubleValue]];
        [self.contato.endereco.geolocalizacao setLongitude:[self.TextFieldLongitude.text doubleValue]];
        
        //DADOS DA EMPRESA
        [self.contato.empresa setRazaoSocial:self.TextFieldRazaoSocial.text];
        [self.contato.empresa setNomeFantasia:self.TextFieldNomeFantasia.text];
        [self.contato.empresa setSlogan:self.TextFieldSlogan.text];
    }
    else {
        Contato *novoContato = [NSEntityDescription insertNewObjectForEntityForName:@"Contato" inManagedObjectContext:context];
        
        //DADOS GERAIS DO CONTATO
        [novoContato setFoto:UIImagePNGRepresentation(self.ImageViewFoto.image)];
        [novoContato setNome:self.TextFieldNome.text];
        [novoContato setTelefone:self.TextFieldTelefone.text];
        [novoContato setEmail:self.TextFieldEmail.text];
        [novoContato setUsuario:self.TextFieldUsuario.text];
        [novoContato setSite:self.TextFieldSite.text];
        
        //DADOS DO ENDEREÇO
        Endereco *novoEndereco = [NSEntityDescription insertNewObjectForEntityForName:@"Endereco" inManagedObjectContext:context];
        
        [novoEndereco setCep:self.TextFieldCep.text];
        [novoEndereco setCidade:self.TextFieldCidade.text];
        [novoEndereco setBairro:self.TextFieldBairro.text];
        [novoEndereco setNumero:self.TextFieldNumero.text];
        
        //GEOLOCALIZAÇÃO
        Geolocalizacao *novaGeolocalizacao = [NSEntityDescription insertNewObjectForEntityForName:@"Geolocalizacao" inManagedObjectContext:context];
        
        [novaGeolocalizacao setLatitude:[self.TextFieldLatitude.text doubleValue]];
        [novaGeolocalizacao setLongitude:[self.TextFieldLongitude.text doubleValue]];
        
        [novoEndereco setGeolocalizacao:novaGeolocalizacao];
        [novoContato setEndereco:novoEndereco];
        
        //DADOS DA EMPRESA
        Empresa *novaEmpresa = [NSEntityDescription insertNewObjectForEntityForName:@"Empresa" inManagedObjectContext:context];
        
        [novaEmpresa setRazaoSocial:self.TextFieldRazaoSocial.text];
        [novaEmpresa setNomeFantasia:self.TextFieldNomeFantasia.text];
        [novaEmpresa setSlogan:self.TextFieldSlogan.text];
        
        [novoContato setEmpresa:novaEmpresa];
    }
    
    NSError *erroCoreData;
    if (![context save:&erroCoreData]) {
        //NSLog(@"\n\n\nErro ao salvar o contato! %@\n\n\n", erroCoreData);
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Erro"
                                                                                 message:@"Ocorreu um erro ao salvar o contato."
                                                                          preferredStyle:UIAlertControllerStyleAlert];
        
        [alertController addAction:[UIAlertAction actionWithTitle:@"OK"
                                                            style:UIAlertActionStyleCancel
                                                          handler:nil]];
        
        [self presentViewController:alertController animated:YES completion:nil];
    }
    
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark - UIImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info {
    UIImage *imagemEscolhida = info[UIImagePickerControllerEditedImage];
    NSData *bytesDaImagem = UIImagePNGRepresentation(imagemEscolhida);
    [self.ImageViewFoto setImage:[UIImage imageWithData:bytesDaImagem]];
    
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
