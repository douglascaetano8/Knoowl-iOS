//
//  Empresa+CoreDataClass.m
//  ClassHive
//
//  Created by Giga Digital on 23/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import "Empresa+CoreDataClass.h"
#import "Contato+CoreDataClass.h"
@implementation Empresa

@end
