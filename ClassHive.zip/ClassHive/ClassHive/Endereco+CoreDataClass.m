//
//  Endereco+CoreDataClass.m
//  ClassHive
//
//  Created by Giga Digital on 23/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import "Endereco+CoreDataClass.h"
#import "Contato+CoreDataClass.h"
#import "Geolocalizacao+CoreDataClass.h"
@implementation Endereco

@end
