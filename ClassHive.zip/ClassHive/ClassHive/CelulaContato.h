//
//  CelulaContato.h
//  ClassHive
//
//  Created by Giga Digital on 12/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CelulaContato : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *ImageViewFoto;
@property (weak, nonatomic) IBOutlet UILabel *LabelNome;
@property (weak, nonatomic) IBOutlet UILabel *LabelTelefone;
@property (weak, nonatomic) IBOutlet UILabel *LabelEmail;

@end
