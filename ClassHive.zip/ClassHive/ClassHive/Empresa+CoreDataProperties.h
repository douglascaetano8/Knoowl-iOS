//
//  Empresa+CoreDataProperties.h
//  ClassHive
//
//  Created by Giga Digital on 23/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import "Empresa+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Empresa (CoreDataProperties)

+ (NSFetchRequest<Empresa *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *nomeFantasia;
@property (nullable, nonatomic, copy) NSString *razaoSocial;
@property (nullable, nonatomic, copy) NSString *slogan;
@property (nullable, nonatomic, retain) Contato *contato;

@end

NS_ASSUME_NONNULL_END
