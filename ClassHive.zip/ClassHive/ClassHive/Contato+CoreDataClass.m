//
//  Contato+CoreDataClass.m
//  ClassHive
//
//  Created by Giga Digital on 23/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import "Contato+CoreDataClass.h"
#import "Empresa+CoreDataClass.h"
#import "Endereco+CoreDataClass.h"
@implementation Contato

@end
