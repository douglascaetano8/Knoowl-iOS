//
//  CelulaContato.m
//  ClassHive
//
//  Created by Giga Digital on 12/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import "CelulaContato.h"

@implementation CelulaContato

- (void)awakeFromNib {
    [super awakeFromNib];
    
    self.ImageViewFoto.layer.cornerRadius = 5;
    self.ImageViewFoto.clipsToBounds = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
