//
//  Contato+CoreDataProperties.h
//  ClassHive
//
//  Created by Giga Digital on 23/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import "Contato+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Contato (CoreDataProperties)

+ (NSFetchRequest<Contato *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *email;
@property (nullable, nonatomic, retain) NSData *foto;
@property (nullable, nonatomic, copy) NSString *nome;
@property (nullable, nonatomic, copy) NSString *site;
@property (nullable, nonatomic, copy) NSString *telefone;
@property (nullable, nonatomic, copy) NSString *usuario;
@property (nullable, nonatomic, retain) Empresa *empresa;
@property (nullable, nonatomic, retain) Endereco *endereco;

@end

NS_ASSUME_NONNULL_END
