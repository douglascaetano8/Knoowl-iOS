//
//  Endereco+CoreDataProperties.m
//  ClassHive
//
//  Created by Giga Digital on 23/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import "Endereco+CoreDataProperties.h"

@implementation Endereco (CoreDataProperties)

+ (NSFetchRequest<Endereco *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"Endereco"];
}

@dynamic bairro;
@dynamic cep;
@dynamic cidade;
@dynamic numero;
@dynamic geolocalizacao;
@dynamic contato;

@end
